close all
clear
clc

%% Variable parameters

% Define point in the plane
plane_z = 0.30;                                                             % Height of the parallel plane to 8-figure coil

% Define whitch dipole approximation you want to compute
% Using Gauss-Lengendre distribution impose GL = 1
% Using Gauss-Chebyshev distribution impose GL differents from 0 and 1
% Using equidistant nodes impose GL = 0
GL = 1;
% If you choose equidistant nodes, you can choose distance from the center
% of the plane: dist = 0 indicates point farther from the center, dist =
% 0.03 indicates point nearer to the center
dist = 0.03;

% For visualize all figures impose fig = 1
fig = 0;

% Impose it to 1 if you want a complete 8-figure coil with the two straght
% lines
complete = 0;

%% Project
% Initialize arrays to store results
results = [];

% Define the sets of values for each variable
x_point_plane_values = [20, 30];
y_point_plane_values = [15, 20, 25];
x_dip_values = [10, 25, 50, 80];
y_dip_values = [10, 15, 20];

for x_point_plane = x_point_plane_values
    for y_point_plane = y_point_plane_values
        for x_dip = x_dip_values
            for y_dip = y_dip_values
                [MSE_BX, MSE_BY, MSE_BZ, MSE_B, Abs_B, Percent_B, n_plane, n_dipoles] = project_CE(x_point_plane, y_point_plane, plane_z, ...
                    x_dip, y_dip, GL, fig, dist, complete);

                % Collect results into a table row

                resultRow = table(n_plane, n_dipoles, MSE_BX, MSE_BY, MSE_BZ, MSE_B, Abs_B, Percent_B);

                % Append the current result row to results
                results = [results; resultRow];

            end
        end
    end
end

% Sort the results table by n_plane and then by n_dipoles in ascending order
sortedResults = sortrows(results, {'n_plane', 'n_dipoles'});

% Save the sorted table to a CSV file
writetable(sortedResults, 'Gauss_Lengendre.csv');

% Display the sorted results
disp(sortedResults);