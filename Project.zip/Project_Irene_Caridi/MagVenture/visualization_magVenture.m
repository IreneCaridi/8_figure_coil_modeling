close all
clear
clc

%% Load ccd file

% SimNIBS creates a figure-eight coil with all points or in a sparse version.
% Set complete = 0 to visualize the sparse version.
complete = 0;

if complete
    % Load ccd file for complete coil
    opts = detectImportOptions('dipole_fit/coildata/MagVenture_MC-B70_dipole-fit.ccd', 'FileType', 'text', 'Delimiter', ' ');

    % Specify the variable names
    opts.VariableNames = {'CenterX', 'CenterY', 'CenterZ', 'DirX', 'DirY', 'DirZ'};

    T = readtable('dipole_fit/coildata/MagVenture_MC-B70_dipole-fit.ccd', opts);
else
    % Load ccd file for sparse coil
    opts = detectImportOptions('dipole_fit/coildata/MagVenture_MC-B70_dipole-fit-sparse.ccd', 'FileType', 'text', 'Delimiter', ' ');

    % Specify the variable names
    opts.VariableNames = {'CenterX', 'CenterY', 'CenterZ', 'DirX', 'DirY', 'DirZ'};

    T = readtable('dipole_fit/coildata/MagVenture_MC-B70_dipole-fit-sparse.ccd', opts);
end

%% Visualization of dipole coil

figure
quiver3(T.CenterX, T.CenterY, T.CenterZ, T.DirX, T.DirY, T.DirZ);
xlabel('X (m)');
ylabel('Y (m)');
zlabel('Z (m)');
title('Magnetic Dipoles');

figure
plot3(T.CenterX, T.CenterY, T.CenterZ, '*');
xlabel('X (m)');
ylabel('Y (m)');
zlabel('Z (m)');
title('Dipole coil');


