function [MSE_BX, MSE_BY, MSE_BZ, MSE_B, Abs_B, Percent_B, n_plane, n_dipoles] = project_CE(x_point_plane, y_point_plane, plane_z, ...
    x_dip, y_dip, GL, fig, dist, complete)

n_dipoles = x_dip*y_dip;                                                    % Number of dipoles
n_plane = x_point_plane*y_point_plane;                                      % Number of point in the plane

%% Create 8-figure coil

radius_ext = 0.05;                                                          % Define the radius external of the spiral
radius_in = 0.032;                                                          % Define the radius internal of the spiral
c = 0.002;                                                                  % Incerement per revolution
center_dist = 0.06;                                                         % Distance from the center
n_pts_l1 = 3;                                                               % Number of point in the line between the two spiral
n_pts_l2 = 5;                                                               % Number of point in the two straight lines

[x_coil, y_coil, z_coil, n_segments] = create_8_figure_coil(radius_ext, radius_in, c, center_dist, ...
    n_pts_l1, n_pts_l2, complete);

fprintf('Number of segments in the coil: %d\n', n_segments)

if fig
    figure()
    plot(x_coil,y_coil)
    axis equal
    title('8-figure coil')
    xlabel('X (m)')
    ylabel('Y (m)')
end

%% Biot-Savart law for a point

% Define point P
P = [0.05, 0, 0.25];

% Calculate differential length elements
deltal = [diff(x_coil); diff(y_coil); diff(z_coil)]';

% Calculate the midpoints of each segment
midpoints = (([x_coil(1:end-1); y_coil(1:end-1); z_coil(1:end-1)] + ...
              [x_coil(2:end); y_coil(2:end); z_coil(2:end)] ) ./ 2)';

% Define constant current and permeability 
I = 1;
u0 = 4*pi*10^(-7);

[B_point] = BS_one_point(P, deltal, midpoints, I, u0, fig, x_coil, y_coil, z_coil);

%% Biot-Savart law for a plane

% Define a plane
x_range = linspace(-10*radius_ext, 10*radius_ext, x_point_plane);
y_range = linspace(-10*radius_ext, 10*radius_ext, y_point_plane);
[X, Y] = meshgrid(x_range, y_range);
Z = plane_z*ones(size(Y));

if fig
    figure()
    plot3(x_coil, y_coil, z_coil);
    hold on
    plot3(X, Y, Z, '*');
    title('Position of plane and 8-figure coil')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
end 

[BX_biot_savart, BY_biot_savart, BZ_biot_savart, B_magnitude] = BS_plane(x_point_plane, y_point_plane, X, Y, Z, ...
    deltal, midpoints, I, u0, fig, x_coil, y_coil, z_coil);

% %% Check the simmetry of the field components
% 
% [is_symmetric_Bx, is_symmetric_By, is_symmetric_Bz] = checkFieldSymmetry(x_range, y_range, ...
%     BX_biot_savart, BY_biot_savart, BZ_biot_savart, fig, X, Y, x_coil, y_coil, z_coil);
% 
% % Display the results
% fprintf('Symmetry check results:\n');
% fprintf('B_x is symmetric: %d\n', is_symmetric_Bx);
% fprintf('B_y is symmetric: %d\n', is_symmetric_By);
% fprintf('B_z is symmetric: %d\n', is_symmetric_Bz);

%% Create dipole plane

x_min = -2*radius_ext;
x_max = 2*radius_ext;
y_min = -radius_ext;
y_max = radius_ext;

if GL == 1
    % Using Gauss-Lengendre distribution
    [x_nodes, x_weights] = lgwt(x_dip, x_min, x_max);
    [y_nodes, y_weights] = lgwt(y_dip, y_min, y_max);
elseif GL == 0
    % Using equidistant nodes
    x_nodes = linspace(x_min+dist, x_max-dist, x_dip);
    y_nodes = linspace(y_min+dist/2, y_max-dist/2, y_dip);
else
    % Using Gauss-Chebyshev distribution
    theta_x = (2*(1:x_dip) - 1) * pi / (2*x_dip);
    theta_y = (2*(1:y_dip) - 1) * pi / (2*y_dip);
    x_nodes = cos(theta_x).*0.075;
    y_nodes = cos(theta_y).*0.05;
end

[x_dipoles, y_dipoles] = meshgrid(x_nodes, y_nodes);

plane_z_dip = 0;
z_dipoles = plane_z_dip*ones(size(y_dipoles));

if fig
    figure
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    hold on
    plot3(x_coil,y_coil, z_coil)
    title('Dipole coil')
    xlabel('X (m)')
    ylabel('Y (m)')
    zlabel('Z (m)')
end

% Assuming dipole moment
dip = [1,1,1];

%% Calculate matrix A

Ax = zeros(n_plane, n_dipoles);
Ay = zeros(n_plane, n_dipoles);
Az = zeros(n_plane, n_dipoles);
d=1;

% Define constant
cost_dip = u0 / (4 * pi);

for n = 1:x_dip
    for l = 1:y_dip
        for k = 1:x_point_plane
            for j = 1:y_point_plane
                r_vec = [X(j, k) - x_dipoles(l, n), Y(j, k) - y_dipoles(l, n), Z(j, k) - z_dipoles(l, n)];
                R = sqrt(sum(r_vec.^2, 2));
                if R == 0
                    continue
                end
                r_hat = r_vec ./ R;
                m_dot_r_hat = dot(dip, r_hat, 2);
                dB = cost_dip * (3 .* m_dot_r_hat .* r_hat - dip) ./ (R.^3);
                a = dB ./ dip;

                idx = j+(k-1)*y_point_plane;
                Ax(idx,d) = Ax(idx,d) + a(1);
                Ay(idx,d) = Ay(idx,d) + a(2);
                Az(idx,d) = Az(idx,d) + a(3);
            end
        end
        d = d+1;
    end
end

%% Calculate real dipole moments

% Flatten the magnetic field components into a single vector B
B = zeros(n_plane, 3);

for k = 1:x_point_plane
    for j = 1:y_point_plane
        idx = j+(k-1)*y_point_plane;
        B(idx,1) = BX_biot_savart(j,k);
        B(idx,2) = BY_biot_savart(j,k);
        B(idx,3) = BZ_biot_savart(j,k);
    end
end

max_iterations = min(size(Ax,1),20);
tolerance = 1e-6;

if n_plane >= n_dipoles
    fprintf('Least-squares method is used\n');
    % Check if least-squares solution converges
    while true
        % Using least-squares solution to linear equations
        [mom_x, flag_x] = lsqr(Ax, B(:,1), tolerance, max_iterations);
        [mom_y, flag_y] = lsqr(Ay, B(:,2), tolerance, max_iterations);
        [mom_z, flag_z] = lsqr(Az, B(:,3), tolerance, max_iterations);

        % Check if all flags are zero
        if flag_x == 0 && flag_y == 0 && flag_z == 0
            break;
        end

        % Increase the number of iterations for the next run
        max_iterations = max_iterations + 10;
    end
elseif n_plane < n_dipoles
    fprintf('Minimum norm least-squares method is used\n');
    % Using minimum norm least-squares solution to linear equation
    lambda = 1e-4;
    Ax_reg = Ax + lambda .* eye(size(Ax));
    Ay_reg = Ay + lambda .* eye(size(Ay));
    Az_reg = Az + lambda .* eye(size(Az));
    
    mom_x = lsqminnorm(Ax_reg, B(:,1), 'warn');
    mom_y = lsqminnorm(Ay_reg, B(:,2), 'warn');
    mom_z = lsqminnorm(Az_reg, B(:,3), 'warn');
end

% Real dipole moments
dipole_moments = [mom_x, mom_y, mom_z];

if fig
    figure()
    quiver3(x_dipoles(:), y_dipoles(:), z_dipoles(:), mom_x, mom_y, mom_z);
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('Magnetic Dipoles');

    figure()
    plot3(x_dipoles, y_dipoles, z_dipoles, '*');
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('Dipole coil');
end

%% Biot-Savart law with dipole approximation

[BX_dipole, BY_dipole, BZ_dipole, B_magnitude_dipole] = BS_dipole(x_point_plane, y_point_plane, x_dipoles, y_dipoles, z_dipoles, ...
    dipole_moments, X, Y, Z, u0, fig);

%% Comparison between two methods

% Calculate mean square error
MSE_BX = immse(BX_biot_savart, BX_dipole);
MSE_BY = immse(BY_biot_savart, BY_dipole);
MSE_BZ = immse(BZ_biot_savart, BZ_dipole);
MSE_B = immse(B_magnitude, B_magnitude_dipole);

% Calculate Absolute MSE
Abs_B = mean(abs(B_magnitude - B_magnitude_dipole), 'all');

% Calcualte Relative MSE
Rel_Error = mean(abs((B_magnitude - B_magnitude_dipole) ./ B_magnitude), 'all');
Percent_B = Rel_Error * 100;

end 