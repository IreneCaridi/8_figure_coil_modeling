function [B_point] = BS_one_point(P, deltal, midpoints, I, u0, fig, x_coil, y_coil, z_coil)

%{

%%% INPUT %%%
P: point in which calculate magnetic field
deltal: differential length elements
midpoints: midpoints of each differential length element
I: constant current
u0: permeability
fig: logical value for figures visualization
% THE COORDINATES OF THE COIL ARE OPTIONAL IF FIGURE IS EQUAL TO 0
x_coil: OPTIONAL, X coordinate of 8-figure coil
y_coil: OPTIONAL, Y coordinate of 8-figure coil
z_coil: OPTIONAL, Z coordinate of 8-figure coil

%%% OUTPUT %%%
B_point: magnetic field component calculated in point P wiht line elements

%}

% Calculate vectors r and distances R
r = P - midpoints;
R = sqrt(sum(r .^ 2, 2));

% Define constant
cost = I*u0/(4*pi);

% Biot-Savart law
prodVect = cross(deltal, r, 2);
num = cost .* prodVect;
B_point = sum(num ./ R.^3, 1);

if fig
    % For visualization the magnetic field B is moltiplicated by a power of
    % 10 to increase its value
    B_point = B_point*10^4;

    figure(1)
    plot3(x_coil, y_coil, z_coil)
    hold on
    plot3(P(1), P(2), P(3), '*')
    title('Position of point P and 8-figure coil')

    figure(2)
    plot3(x_coil, y_coil, z_coil);
    hold on;
    quiver3(P(1), P(2), P(3), B_point(1), B_point(2), B_point(3), 'MaxHeadSize', 2, 'AutoScale', 'off');
    xlabel('x');
    ylabel('y');
    zlabel('z');
    axis equal
    title('Magnetic Field Vector at point P');
end

end