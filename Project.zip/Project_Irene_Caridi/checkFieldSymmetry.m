function [is_symmetric_Bx, is_symmetric_By, is_symmetric_Bz] = checkFieldSymmetry(x_range, y_range, BX_biot_savart, BY_biot_savart, BZ_biot_savart, fig, ...
    X, Y, x_coil, y_coil, z_coil)

% Check symmetry for Bx, By, and Bz
is_symmetric_Bx = checkSymmetry(BX_biot_savart, x_range);
is_symmetric_By = checkSymmetry(BY_biot_savart, x_range);
is_symmetric_Bz = checkSymmetry(BZ_biot_savart, x_range);

if fig
    figure()
    surf(X, Y, BX_biot_savart);
    shading interp;
    hold on
    plot3(x_coil, y_coil, z_coil)
    title('Magnetic Field B_x Component in the Plane (Biot-Savart)')
    colorbar

    figure()
    surf(X, Y, BY_biot_savart);
    shading interp;
    hold on
    plot3(x_coil, y_coil, z_coil)
    title('Magnetic Field B_y Component in the Plane (Biot-Savart)')
    colorbar

    figure()
    surf(X, Y, BZ_biot_savart);
    shading interp;
    hold on
    plot3(x_coil, y_coil, z_coil)
    title('Magnetic Field B_z Component in the Plane (Biot-Savart)')
    colorbar
end

end
