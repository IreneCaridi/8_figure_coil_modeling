function [BX_biot_savart, BY_biot_savart, BZ_biot_savart, B_magnitude] = BS_plane(x_point_plane, y_point_plane, ...
    X, Y, Z, deltal, midpoints, I, u0, fig, x_coil, y_coil, z_coil)

%{

%%% INPUT %%%
x_point_plane: Number of points for x side in the plane
y_point_plane: Number of points for y side in the plane
X: X coordinates of plane in with you want to calculate magnetic field
Y: Y coordinates of plane in with you want to calculate magnetic field
Z: Z coordinates of plane in with you want to calculate magnetic field
deltal: differential length elements
midpoints: midpoints of each differential length element
I: constant current
u0: permeability
fig: logical value for figures visualization
% THE COORDINATES OF THE COIL ARE OPTIONAL IF FIGURE IS EQUAL TO 0
x_coil: OPTIONAL, X coordinate of 8-figure coil
y_coil: OPTIONAL, Y coordinate of 8-figure coil
z_coil: OPTIONAL, Z coordinate of 8-figure coil

%%% OUTPUT %%%
Magnetic field and its componentes calculated in the plane [X, Y, Z]
BX_biot_savart: X component of magnetic field calculated with line elements
BY_biot_savart: Y component of magnetic field calculated with line elements
BZ_biot_savart: Z component of magnetic field calculated with line elements
B_biot_savart: magnetic field calculated with line elements

%}

% Initialization of magnetic field components
BX_biot_savart = zeros(y_point_plane, x_point_plane);
BY_biot_savart = zeros(y_point_plane, x_point_plane);
BZ_biot_savart = zeros(y_point_plane, x_point_plane);

% Define constant
cost = I*u0/(4*pi);

% Calculate Biot-Savart law
for k = 1:x_point_plane
    for j = 1:y_point_plane
        r_vecs = [X(j, k) - midpoints(:, 1), Y(j, k) - midpoints(:, 2), Z(j, k) - midpoints(:, 3)];
        R = sqrt(sum(r_vecs .^ 2, 2));
        valid_R = R > 0;
        r_vecs = r_vecs(valid_R, :);
        dL_valid = deltal(valid_R, :);
        R_valid = R(valid_R);
        dB = cost * cross(dL_valid, r_vecs, 2) ./ (R_valid.^3);
        B_field = sum(dB, 1);
        BX_biot_savart(j, k) = B_field(1);
        BY_biot_savart(j, k) = B_field(2);
        BZ_biot_savart(j, k) = B_field(3);
    end
end

% Combine magnetic field components into magnitude
B_magnitude = sqrt(BX_biot_savart.^2 + BY_biot_savart.^2 + BZ_biot_savart.^2);

if fig
    figure()
    plot3(x_coil, y_coil, z_coil);
    hold on
    quiver3(X, Y, Z, BX_biot_savart, BY_biot_savart, BZ_biot_savart, 'MaxHeadSize', 2);
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('Magnetic Field Vector in the plane (Biot-Savart)')

    figure()
    surf(X, Y, Z, B_magnitude);
    hold on
    plot3(x_coil, y_coil, z_coil)
    shading interp;
    title('Magnetic Field')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    a=colorbar;
    a.Label.String = 'Magnetic field (T)';
end

end