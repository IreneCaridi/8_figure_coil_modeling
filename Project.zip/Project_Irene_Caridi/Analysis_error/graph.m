clear
close all
clc

%% Show graphs

% Read the data from the CSV files
eq_0 = readtable("Equidistant_0.csv");
eq_003 = readtable("Equidistant_003.csv");
GC = readtable("Gauss_Chebyshev.csv");
GL = readtable("Gauss_Lengendre.csv");

tables = {eq_0, eq_003, GC, GL};
names = {'eq0', 'eq003', 'GC', 'GL'};
% 300, 400, 450, 500, 600 and 750 points
n_plane = 400;

% flag: 0 for minimum norm least squares method;
%       1 for least squares method;
%       2 for both
flag = 2;

str_pe = sprintf('Relative E: %d points in the plane', n_plane);
str_ae = sprintf('MAE: %d points in the plane', n_plane);

% Show heatmap: number of dipoles - number on plane for each distribution
plot_E_distribution(tables, names, 7)
plot_E_distribution(tables, names, 8)

% Show heatmap: number of dipoles - four distribution for a give plane
plot_E_heatmap(tables, names, str_pe, 8, n_plane, flag)
plot_E_heatmap(tables, names, str_ae, 7, n_plane, flag)

% Show plot: number of dipoles - four distribution for a give plane
plot_E(tables, names, str_pe, 8, n_plane, flag);
plot_E(tables, names, str_ae, 7, n_plane, flag);

% Show MSE
if flag == 2
    figure
    for i = 1:12
        subplot(3, 5, i)
        plots_MSE(tables, names, i, n_plane, flag)
    end
end
