function [] = plot_E(tables, names, str, idx, n_plane_filter, flag)
%{
PLOTS_TABLES plots absolute E, realtive E for all combination of points in the plane and
dipoles

%%% INPUT %%%
tables: cell array of tables containing error data
names: cell array of names for legend entries
str: title of plot
idx: index of the column to plot from each table
n_plane_filter: value of n_plane to filter the rows to be plotted
flag: 0 for minimum norm least squares method;
      1 for least squares method;
      2 for both
%}

% Create a new figure
figure();
hold on;

% Loop through each table and plot the data
for i = 1:length(tables)
    tbl = tables{1, i};
    
    % Filter rows based on the value of n_plane
    filtered_tbl = tbl(tbl.n_plane == n_plane_filter, :);
    
    if isempty(filtered_tbl)
        continue;
    end
    
    % Additional filtering based on the flag
    if flag == 0
        filtered_tbl = filtered_tbl(filtered_tbl{:, 1} < filtered_tbl{:, 2}, :);
    elseif flag == 1
        filtered_tbl = filtered_tbl(filtered_tbl{:, 1} > filtered_tbl{:, 2}, :);
    elseif flag ~= 2
        error('Invalid flag value. Use 0 for first < second, 1 for first > second, or 2 for all rows.');
    end
    
    if isempty(filtered_tbl)
        continue;
    end
    
    x1 = filtered_tbl{:, 1};
    x2 = filtered_tbl{:, 2};
    y = filtered_tbl{:, idx};
    
    % Combine the first two columns into a single set of labels
    x_labels = strcat(num2str(x2));
    
    % Plot the data
    plot(y, 'o-', 'DisplayName', names{i});
    
    % Customize the x-axis with combined labels
    xticks(1:length(x_labels));
    xticklabels(x_labels);
end

xlabel('number of dipoles');
if idx == 8
    ylabel('(%)')
    if flag == 0
        str_fig = sprintf('%d_mlsm_E.png', n_plane_filter);
    elseif flag == 1
        str_fig = sprintf('%d_lsm_E.png', n_plane_filter);
    else
       str_fig = sprintf('%d_all_E.png', n_plane_filter); 
    end
else
    ylabel('(T)')
    if flag == 0
        str_fig = sprintf('%d_mlsm_A.png', n_plane_filter);
    elseif flag == 1
        str_fig = sprintf('%d_lsm_A.png', n_plane_filter);
    else
       str_fig = sprintf('%d_all_A.png', n_plane_filter); 
    end
end
title(str);
legend('show');

grid on;
hold off;

saveas(gcf, fullfile('plot', str_fig));

