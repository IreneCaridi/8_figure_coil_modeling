function [] = plot_E_distribution(tables, names, idx)
%{
PLOTS_TABLES generates heatmaps for each distribution with 
n_dipoles on the x-axis and n_plane on the y-axis.

%%% INPUT %%%
tables: cell array of tables containing error data
names: cell array of names for legend entries
idx: index of the column to plot from each table
%}

% Loop through each table to create a heatmap
for i = 1:length(tables)
    tbl = tables{i};
    
    % Extract unique values of n_plane and n_dipoles
    n_planes = unique(tbl.n_plane);
    n_dipoles = unique(tbl.n_dipoles);
    
    % Initialize the matrix to store the values for the heatmap
    heatmap_data = NaN(length(n_planes), length(n_dipoles));
    
    % Fill the heatmap matrix with the data
    for j = 1:length(n_planes)
        for k = 1:length(n_dipoles)
            % Find the corresponding rows in the table
            rows = tbl(tbl.n_plane == n_planes(j) & tbl.n_dipoles == n_dipoles(k), :);
            if ~isempty(rows)
                % If there are multiple rows, take the mean value
                heatmap_data(j, k) = mean(rows{:, idx});
            end
        end
    end
    
    % Create a new figure for the heatmap
    figure();
    
    % Plot the heatmap
    imagesc(heatmap_data);
    c = colorbar;
    
    % Customize the axes
    xticks(1:length(n_dipoles));
    xticklabels(n_dipoles);
    xlabel('Number of dipoles');
    
    yticks(1:length(n_planes));
    yticklabels(n_planes);
    ylabel('Number of points in the plane');
    
   
    % Customize the colorbar label based on the index
    if idx == 8
        c.Label.String = 'Relative error (%)';
        str_fig = sprintf('%s_heatmap_E.png', names{i});
    else
        c.Label.String = 'MAE (T)';
        str_fig = sprintf('%s_heatmap_A.png', names{i});
    end
    
    % Add a title
    title(names{i});
    
    % Save the figure
    saveas(gcf, fullfile('heatmap', str_fig));
    
end

end
