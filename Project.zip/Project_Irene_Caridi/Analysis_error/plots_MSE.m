function [] = plots_MSE(tables, names, idx, n_plane_filter, flag)
%{
PLOTS_3COMPONENTS plots MSE of the magnetic field components from multiple
tables when magnetic field is calculated with three components

%%% INPUT %%%
tables: cell array of tables containing MSE data
names: cell array of names for legend entries
idx: index of the row to plot from each table, corresponding to a specific
combination of number of points in the plane and number of dipoles
n_plane_filter: value of n_plane to filter the rows to be plotted
flag: 0 to plot rows where the first column is less than the second column;
      1 to plot rows where the first column is greater than the second column;
      2 to plot all rows
%}

% Define the names for x-axis labels
nam = {'x', 'y', 'z', 'magnitude'};

% Specify columns to plot which are stored magnetic field components
columns = 3:6;

hold on;

% Loop through each table in tables
for i = 1:length(tables)
    table_data = tables{i};
    
    % Filter rows based on the value of n_plane
    filtered_tbl = table_data(table_data.n_plane == n_plane_filter, :);
    
    % Additional filtering based on the flag
    if flag == 0
        filtered_tbl = filtered_tbl(filtered_tbl{:, 1} < filtered_tbl{:, 2}, :);
    elseif flag == 1
        filtered_tbl = filtered_tbl(filtered_tbl{:, 1} > filtered_tbl{:, 2}, :);
    elseif flag ~= 2
        error('Invalid flag value. Use 0 for first < second, 1 for first > second, or 2 for all rows.');
    end
    
    % Ensure the idx is within the bounds of the filtered table
    if idx > height(filtered_tbl)
        warning('Index exceeds the number of rows in the filtered table for dataset %d.', i);
        continue;
    end
    
    % Extract data from the table for the specified row
    data_to_plot = filtered_tbl{idx, columns};
    
    % Plot the data
    plot(data_to_plot, 'o-', 'DisplayName', names{i});
    
    xticks(1:length(columns));
    xticklabels(nam);
end

xlabel('Magnetic field components');
str = sprintf('MSE: %d points in the plane', n_plane_filter);
ylabel(str);
title(sprintf('%d dipoles', filtered_tbl{idx, 2}));
grid on;
legend('show');
hold off;

end
