function [BX_dipole, BY_dipole, BZ_dipole, B_magnitude_dipole] = BS_dipole(x_point_plane, y_point_plane, x_dipoles, y_dipoles, z_dipoles, ...
    dipole_moments, X, Y, Z, u0, fig)

%{

%%% INPUT %%%
x_point_plane: Number of points for x side in the plane
y_point_plane: Number of points for y side in the plane
x_dipoles: X coordinates of dipoles
y_dipoles: Y coordinates of dipoles
z_dipoles: Z coordinates of dipoles
dipole_moments: dipole moments calculated by minimum norm least-squares solution to linear equation
X: X coordinates of plane in with you want to calculate magnetic field
Y: Y coordinates of plane in with you want to calculate magnetic field
Z: Z coordinates of plane in with you want to calculate magnetic field
u0: permeability
fig: logical value for figures visualization

%%% OUTPUT %%%
Magnetic field and its componentes calculated in the plane [X, Y, Z]
BX_dipole: X component of magnetic field calculated with dipole
approximation
BY_dipole: Y component of magnetic field calculated with dipole
approximation
BZ_dipole: Z component of magnetic field calculated with dipole
approximation
B_magnitude_dipole: magnetic field calculated with dipole approximation

%}

% Define constant
cost_dip = u0/(4*pi);

BX_dipole = zeros(y_point_plane, x_point_plane);
BY_dipole = zeros(y_point_plane, x_point_plane);
BZ_dipole = zeros(y_point_plane, x_point_plane);

for k = 1:x_point_plane 
    for j = 1:y_point_plane
        Bx = 0;
        By = 0;
        Bz = 0;
        d = 1;
        
        r_vec = [X(j, k) - x_dipoles(:), Y(j, k) - y_dipoles(:), Z(j, k) - z_dipoles(:)];
        R = sqrt(sum(r_vec.^2, 2));
        non_zero_indices = R ~= 0;
        r_vec = r_vec(non_zero_indices, :);
        R = R(non_zero_indices);
        r_hat = r_vec ./ R;
        m_dot_r_hat = dot(dipole_moments, r_hat, 2);
        dB = cost_dip * (3 .* m_dot_r_hat .* r_hat - dipole_moments) ./ (R.^3);
        
        BX_dipole(j, k) = sum(dB(:, 1));
        BY_dipole(j, k) = sum(dB(:, 2));
        BZ_dipole(j, k) = sum(dB(:, 3));
    end
end

%Combine magnetic field components into magnitude
B_magnitude_dipole = sqrt(BX_dipole.^2 + BY_dipole.^2 + BZ_dipole.^2);

if fig
    figure()
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    hold on
    quiver3(X, Y, Z, BX_dipole, BY_dipole, BZ_dipole);
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('Magnetic Field Vector in the plane (Dipole Approximation)')

    figure()
    surf(X, Y, Z, B_magnitude_dipole);
    hold on
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    shading interp;
    title('Magnetic Field with dipoles')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    a=colorbar;
    a.Label.String = 'Magnetic field (T)';

    figure()
    surf(X, Y, BX_dipole);
    shading interp;
    hold on
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    title('Magnetic Field B_x Component in the Plane (Dipoles)')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    a=colorbar;
    a.Label.String = 'Magnetic component x (T)';

    figure()
    surf(X, Y, BY_dipole);
    shading interp;
    hold on
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    title('Magnetic Field B_y Component in the Plane (Dipoles)')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    a=colorbar;
    a.Label.String = 'Magnetic component y (T)';

    figure()
    surf(X, Y, BZ_dipole);
    shading interp;
    hold on
    plot3(x_dipoles, y_dipoles, z_dipoles, '*')
    title('Magnetic Field B_z Component in the Plane (Dipoles)')
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    a=colorbar;
    a.Label.String = 'Magnetic component z (T)';
end

end