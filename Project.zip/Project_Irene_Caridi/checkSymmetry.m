function is_symmetric = checkSymmetry(B_component, range)
    % Check symmetry of the given magnetic field component matrix B_component
    is_symmetric = true;
    mid_idx = ceil(length(range) / 2);
    
    for i = 1:mid_idx
        % Compare left and right sides of the axis
        if any(abs(B_component(:, i) - B_component(:, end-i+1)) > 1e-6)
            is_symmetric = false;
            disp('The matrix is not symmetric');
            break;
        end
    end
end
