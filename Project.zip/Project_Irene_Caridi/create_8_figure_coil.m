function [x_coil, y_coil, z_coil, n_segments] = create_8_figure_coil(radius_ext, radius_in, c, center_dist, n_pts_l1, n_pts_l2, complete)

%{

%%% INPUT %%%
radius_ext: measure of external radius
radius_in: measure of internal radius:
c: incerement per revolution
center_dist: distance from the center
n_pts_l1: number of point in the line between the two spiral
n_pts_l2: number of point in the two straight lines

% Impose it to 1 if you want a complete 8-figure coil with the two straght
% lines
complete: logical value for create a complete 8-figure coil


%%% OUTPUT %%%
x_coil: OPTIONAL, X coordinate of 8-figure coil
y_coil: OPTIONAL, Y coordinate of 8-figure coil
z_coil: OPTIONAL, Z coordinate of 8-figure coil
n_segments: number of segments in 8-figure coil

%}

n_rev = (radius_ext - radius_in)./c;                                        % number  of revolutions
n_pts = n_rev*100;                                                          % number of points in a spiral fixed at 100 points
i = linspace(0, n_rev, n_pts);      

% Spiral on the left
x_left = (radius_in + c*i).* cos(2*pi*i) - center_dist;
y_left = -(radius_in + c*i).* sin(2*pi*i);
x_left = flip(x_left);
y_left = flip(y_left);

% Spiral on the right
x_right = -(radius_in + c*i).* cos(2*pi*i) + center_dist;
y_right = -(radius_in + c*i).* sin(2*pi*i);

% Link line
k = 0.01;
x_l = linspace(-(center_dist-radius_in-k), center_dist-radius_in-k, n_pts_l1);
y_l = zeros([1, n_pts_l1]);

% Straight line
x_sll = -(center_dist-radius_ext)*ones([1, n_pts_l2]);
y_sll = linspace(0, -(radius_ext+0.15), n_pts_l2);
x_slr = (center_dist-radius_ext)*ones([1, n_pts_l2]);
y_slr = linspace(0, -(radius_ext+0.15), n_pts_l2);
y_sll = flip(y_sll);

% Create one figure
% You can choose if create a complete 8-figure coil with the two straight
% lines imposing complete = 1, or create a 8-figure coil with just the two
% spirale and the link line.
if complete
    x_coil = [x_sll, x_left, x_l, x_right, x_slr];
    y_coil = [y_sll, y_left, y_l, y_right, y_slr];
else
    x_coil = [x_left, x_l, x_right];
    y_coil = [y_left, y_l, y_right];
end
n_segments = size(x_coil,2);
z_coil = zeros(1,n_segments);

end